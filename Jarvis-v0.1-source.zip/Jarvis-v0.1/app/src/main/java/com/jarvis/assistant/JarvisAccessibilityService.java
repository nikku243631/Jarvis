package com.jarvis.assistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PointF;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class JarvisAccessibilityService extends AccessibilityService {
    public static JarvisAccessibilityService instance;

    @Override public void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { if (instance == this) instance = null; }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public boolean clickText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        return clickRecursive(root, text.toLowerCase());
    }
    private boolean clickRecursive(AccessibilityNodeInfo n, String wanted) {
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if ((t != null && t.toString().toLowerCase().contains(wanted)) || (d != null && d.toString().toLowerCase().contains(wanted))) {
            if (n.isClickable()) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            AccessibilityNodeInfo p = n.getParent();
            if (p != null && p.isClickable()) return p.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
        for (int i=0;i<n.getChildCount();i++) { AccessibilityNodeInfo c=n.getChild(i); if(c!=null && clickRecursive(c,wanted)) return true; }
        return false;
    }

    public boolean typeText(String text) {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null) return false;
        AccessibilityNodeInfo target=findEditable(root);
        if(target==null) return false;
        Bundle args=new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text);
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args);
    }
    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n) {
        if(n.isEditable()) return n;
        for(int i=0;i<n.getChildCount();i++){ AccessibilityNodeInfo c=n.getChild(i); if(c!=null){ AccessibilityNodeInfo r=findEditable(c); if(r!=null)return r; }}
        return null;
    }

    public boolean swipeUp() { return swipe(0.50f,0.80f,0.50f,0.25f); }
    public boolean swipeDown() { return swipe(0.50f,0.25f,0.50f,0.80f); }
    private boolean swipe(float sx,float sy,float ex,float ey){
        int w=getResources().getDisplayMetrics().widthPixels, h=getResources().getDisplayMetrics().heightPixels;
        Path p=new Path(); p.moveTo(w*sx,h*sy); p.lineTo(w*ex,h*ey);
        GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,500)).build();
        return dispatchGesture(g,null,null);
    }
    public boolean tap(float x,float y){
        Path p=new Path(); p.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build();
        return dispatchGesture(g,null,null);
    }
    public void goBack(){ performGlobalAction(GLOBAL_ACTION_BACK); }
    public void goHome(){ performGlobalAction(GLOBAL_ACTION_HOME); }
}
