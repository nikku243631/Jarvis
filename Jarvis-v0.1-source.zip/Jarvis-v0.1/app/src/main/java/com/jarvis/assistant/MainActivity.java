package com.jarvis.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    EditText apiKey,input; TextView status,log; TextToSpeech tts; SharedPreferences prefs; final int REQ_SPEECH=91;
    final String MODEL="gemini-3.5-flash";
    @Override public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
        apiKey=findViewById(R.id.apiKey); input=findViewById(R.id.input); status=findViewById(R.id.status); log=findViewById(R.id.log);
        prefs=getSharedPreferences("jarvis",0); apiKey.setText(prefs.getString("key",""));
        tts=new TextToSpeech(this, s->{ if(s==TextToSpeech.SUCCESS) { tts.setLanguage(Locale.ENGLISH); selectMaleVoice(); }});
        findViewById(R.id.saveKey).setOnClickListener(v->{prefs.edit().putString("key",apiKey.getText().toString().trim()).apply(); say("API key saved, Boss.");});
        findViewById(R.id.accessibility).setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        findViewById(R.id.mic).setOnClickListener(v->listen());
        findViewById(R.id.send).setOnClickListener(v->handle(input.getText().toString().trim()));
    }
    void selectMaleVoice(){ if(tts==null)return; for(TextToSpeech.Voice v:tts.getVoices()){String n=v.getName().toLowerCase(); if(n.contains("male") && v.getLocale().getLanguage().equals("en")){tts.setVoice(v);break;}} }
    void listen(){ Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-IN"); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Yes Boss, I'm listening."); try{startActivityForResult(i,REQ_SPEECH);}catch(Exception e){say("Voice input is not available on this phone, Boss.");}}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==REQ_SPEECH && c==RESULT_OK && d!=null){ArrayList<String>a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(a!=null&&!a.isEmpty()){input.setText(a.get(0));handle(a.get(0));}}}
    void handle(String cmd){ if(cmd.isEmpty())return; log("\nBoss: "+cmd); status.setText("Working...");
        String s=cmd.toLowerCase(Locale.ROOT);
        if(runLocal(s,cmd)) return;
        String key=prefs.getString("key",""); if(key.isEmpty()){say("Boss, basic phone commands work without an API key. For AI conversation, paste your Gemini API key and save it."); return;}
        new Thread(()->{try{String reply=gemini(key,cmd); runOnUiThread(()->{log("\nJarvis: "+reply);say(reply);status.setText("Ready, Boss.");});}catch(Exception e){runOnUiThread(()->{log("\nError: "+e.getMessage());say("Boss, Gemini connection failed. Check your internet and API key.");status.setText("API error");});}}).start();
    }
    boolean runLocal(String s,String original){
        if(s.contains("enable phone control")){startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));say("Boss, Accessibility settings khol raha hoon. Jarvis ko ON kar dijiye.");return true;}
        if(s.equals("go back")||s.contains("back jao")||s.contains("piche jao")){ if(JarvisAccessibilityService.instance!=null){say("Ji Boss, back kar raha hoon.");JarvisAccessibilityService.instance.goBack();}else noAccess();return true; }
        if(s.contains("home screen")||s.equals("home")){if(JarvisAccessibilityService.instance!=null){say("Ji Boss, home par aa raha hoon.");JarvisAccessibilityService.instance.goHome();}else noAccess();return true;}
        if(s.contains("scroll down")||s.contains("neeche scroll")){if(JarvisAccessibilityService.instance!=null){say("Ji Boss, neeche scroll kar raha hoon.");JarvisAccessibilityService.instance.swipeUp();}else noAccess();return true;}
        if(s.contains("scroll up")||s.contains("upar scroll")){if(JarvisAccessibilityService.instance!=null){say("Ji Boss, upar scroll kar raha hoon.");JarvisAccessibilityService.instance.swipeDown();}else noAccess();return true;}
        String[] apps={"youtube","whatsapp","instagram","chrome","telegram","spotify","maps","google"};
        for(String a:apps) if(s.contains("open "+a)||s.contains(a+" kholo")||s.contains(a+" khol")){openApp(a);return true;}
        if(s.startsWith("type ")||s.startsWith("likho ")){if(JarvisAccessibilityService.instance!=null){String text=original.substring(original.indexOf(' ')+1);say("Ji Boss, type kar raha hoon.");JarvisAccessibilityService.instance.typeText(text);}else noAccess();return true;}
        return false;
    }
    void openApp(String name){String pkg=null; switch(name){case"youtube":pkg="com.google.android.youtube";break;case"whatsapp":pkg="com.whatsapp";break;case"instagram":pkg="com.instagram.android";break;case"chrome":pkg="com.android.chrome";break;case"telegram":pkg="org.telegram.messenger";break;case"spotify":pkg="com.spotify.music";break;case"maps":pkg="com.google.android.apps.maps";break;case"google":pkg="com.google.android.googlequicksearchbox";break;} Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i!=null){say("Ji Boss, "+name+" khol raha hoon.");startActivity(i);}else say("Boss, "+name+" phone mein installed nahi mil raha.");}
    void noAccess(){say("Boss, phone control permission ON nahi hai. Accessibility settings mein Jarvis ko enable kijiye.");startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}
    void say(String text){log("\nJarvis: "+text); if(tts!=null)tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"jarvis");}
    void log(String s){log.append(s);}
    String gemini(String key,String prompt)throws Exception{
        URL u=new URL("https://generativelanguage.googleapis.com/v1beta/models/"+MODEL+":generateContent"); HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST");c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("x-goog-api-key",key);c.setDoOutput(true);
        JSONObject body=new JSONObject(); JSONArray contents=new JSONArray(); JSONObject content=new JSONObject(); JSONArray parts=new JSONArray(); JSONObject p=new JSONObject(); p.put("text","You are Jarvis, a respectful male personal AI assistant. Address the user as Boss unless they specify another name. Never use disrespectful Hindi or 'tu'. If asked who created you, say Mr. Nikhil created you. Reply naturally in concise Hinglish. User request: "+prompt);parts.put(p);content.put("parts",parts);contents.put(content);body.put("contents",contents);
        OutputStream os=c.getOutputStream();os.write(body.toString().getBytes("UTF-8"));os.close(); int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream();String out=read(is); if(code<200||code>=300)throw new Exception(out); JSONObject r=new JSONObject(out); return r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
    }
    String read(InputStream is)throws Exception{BufferedReader br=new BufferedReader(new InputStreamReader(is));StringBuilder b=new StringBuilder();String x;while((x=br.readLine())!=null)b.append(x);return b.toString();}
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
