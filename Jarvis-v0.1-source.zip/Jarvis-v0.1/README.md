# JARVIS v0.1

First Android MVP for a personal male AI assistant.

## What works in v0.1
- Text commands
- Android speech recognition -> command
- Android Text-to-Speech response
- Gemini API chat (API key entered locally in app)
- Accessibility-service permission flow
- Open YouTube, WhatsApp, Instagram, Chrome, Telegram, Spotify, Maps, Google
- Back/Home/scroll up/down
- Type text into the current editable field

## Build on phone
Use AndroidIDE (or Android Studio) to open this project. Build the debug APK.

1. Open project folder.
2. Let Gradle sync.
3. Build > Assemble Debug.
4. Install `app/build/outputs/apk/debug/app-debug.apk`.
5. Open Jarvis.
6. Optional: paste your Gemini API key in the app and Save.
7. Tap Enable Phone Control and enable Jarvis under Android Accessibility settings.
8. Return to Jarvis and test commands.

## Security
Do not send your API key in chat or publish it in a repository. This v0.1 stores it locally in app preferences. A later version should move sensitive credentials behind a safer backend/key strategy.

## Important
AccessibilityService is powerful and Android requires the user to explicitly enable it. This app only acts after the user enables the service. Some apps expose different UI elements, so automation reliability varies by app/version.
